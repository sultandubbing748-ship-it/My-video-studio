# My Video Studio — online starter

A small online video library. Supabase handles sign-in and the video catalogue; Cloudinary stores and streams the actual video files. Express keeps private API secrets on the server.

## Before you start

Create the Supabase and Cloudinary projects with an adult's help if their account terms require an adult account. Review each provider's current age, privacy, storage, bandwidth and acceptable-use terms. Never publish your service-role key or Cloudinary API secret.

## 1. Configure Supabase

1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase-schema.sql`.
3. In **Project Settings → API**, copy the Project URL, anon/public key and service_role key.
4. In Authentication settings, configure the site's allowed URL and email confirmation settings for your deployed domain.

## 2. Configure Cloudinary

1. Create a Cloudinary account/project.
2. From the dashboard, copy cloud name, API key and API secret.
3. Keep the API secret private. It belongs only in the server environment variables.

## 3. Configure the app

1. Copy `.env.example` to `.env` and fill in the six values.
2. In `public/index.html`, replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY` with the Supabase Project URL and anon/public key.
3. Install and run:

   ```bash
   npm install
   npm start
   ```

4. Open `http://localhost:3000`.

## 4. Deploy online with Render

1. Put this project in a GitHub repository.
2. In Render, create a **New Web Service** and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add the environment variables from `.env.example` in Render's Environment settings.
6. Deploy. Open the Render URL and test sign-up, sign-in, upload, playback and deletion.
7. In Supabase Authentication URL settings, add your Render URL as the site URL / allowed redirect URL.

## Important notes

- This is a starter, not a large-scale video platform. The browser upload limit is set to 100 MB; your Cloudinary plan may impose lower limits, file-duration limits or bandwidth limits.
- Videos are delivered using Cloudinary URLs. Anyone who gets a copied video URL may be able to view that video. Do not upload private or sensitive footage.
- Supabase Row Level Security restricts each user's library records to that user. The server checks ownership before deleting a Cloudinary file.
- For production, add rate limiting, stronger upload quotas, moderation/reporting, backups, monitoring, and a privacy policy. Consider private/authenticated delivery if shareable public URLs are not appropriate.
- Never put `SUPABASE_SERVICE_ROLE_KEY` or `CLOUDINARY_API_SECRET` in browser code or a public Git repository.
