require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const { createClient } = require("@supabase/supabase-js");
const cloudinary = require("cloudinary").v2;

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const required = ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY",
  "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET"];
for (const key of required) {
  if (!process.env[key]) console.warn(`Missing environment variable: ${key}`);
}

const supabaseAuth = createClient(
  process.env.SUPABASE_URL || "https://example.supabase.co",
  process.env.SUPABASE_ANON_KEY || "placeholder"
);
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL || "https://example.supabase.co",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "placeholder",
  { auth: { autoRefreshToken: false, persistSession: false } }
);

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

async function requireUser(req, res, next) {
  try {
    const auth = req.headers.authorization || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
    if (!token) return res.status(401).json({ error: "Please sign in first." });
    const { data, error } = await supabaseAuth.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: "Your session expired. Please sign in again." });
    req.user = data.user;
    next();
  } catch (e) {
    res.status(401).json({ error: "Could not verify your session." });
  }
}

app.get("/api/health", (_req, res) => res.json({ ok: true }));

// The API secret stays on the server. The browser receives only a short-lived upload signature.
app.post("/api/upload-signature", requireUser, (req, res) => {
  const timestamp = Math.floor(Date.now() / 1000);
  const folder = `my-video-studio/${req.user.id}`;
  const public_id = crypto.randomUUID();
  const params = { folder, public_id, timestamp };
  const toSign = Object.keys(params).sort().map(k => `${k}=${params[k]}`).join("&");
  const signature = crypto.createHash("sha1")
    .update(toSign + process.env.CLOUDINARY_API_SECRET)
    .digest("hex");

  res.json({
    cloudName: process.env.CLOUDINARY_CLOUD_NAME,
    apiKey: process.env.CLOUDINARY_API_KEY,
    timestamp, folder, public_id, signature
  });
});

app.delete("/api/videos/:id", requireUser, async (req, res) => {
  try {
    const { data: video, error: findError } = await supabaseAdmin
      .from("videos").select("id, owner_id, public_id, resource_type")
      .eq("id", req.params.id).single();

    if (findError || !video) return res.status(404).json({ error: "Video not found." });
    if (video.owner_id !== req.user.id) return res.status(403).json({ error: "You can only delete your own videos." });

    await cloudinary.uploader.destroy(video.public_id, { resource_type: "video", invalidate: true });
    const { error: deleteError } = await supabaseAdmin.from("videos")
      .delete().eq("id", video.id).eq("owner_id", req.user.id);
    if (deleteError) throw deleteError;
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Could not delete this video. Please try again." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`My Video Studio running on port ${port}`));
