-- Run this entire script in your Supabase project's SQL Editor.
create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  secure_url text not null,
  public_id text not null unique,
  bytes bigint not null default 0,
  resource_type text not null default 'video',
  created_at timestamptz not null default now()
);

alter table public.videos enable row level security;

create policy "Users can view their own videos"
on public.videos for select
to authenticated
using (auth.uid() = owner_id);

create policy "Users can add their own videos"
on public.videos for insert
to authenticated
with check (auth.uid() = owner_id);

-- Deletion is performed through the server so the cloud file is deleted too.
-- Do not add a client-side DELETE policy.
